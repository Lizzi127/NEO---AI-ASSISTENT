import { defineAuthConfig } from "convex/server";

export default defineAuthConfig({
  providers: [],
});
